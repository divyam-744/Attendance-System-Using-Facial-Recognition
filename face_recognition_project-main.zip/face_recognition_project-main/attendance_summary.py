import os
import pandas as pd
import pickle
from glob import glob
import re
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter

# Load student names from names.pkl
with open("data/names.pkl", "rb") as f:
    raw_names = list(set(pickle.load(f)))

def sort_key(name):
    match = re.search(r'_(\d+)$', name)
    return int(match.group(1)) if match else float('inf')

all_names = sorted(raw_names, key=sort_key)

attendance_folder = os.path.join(os.path.dirname(__file__), "Attendance")
summary_excel = "attendance_summary.xlsx"

attendance_data = {}

csv_files = sorted(glob(os.path.join(attendance_folder, "Attendance_*.csv")))

for file_path in csv_files:
    date = os.path.basename(file_path).split("_")[1].split(".")[0]
    try:
        df = pd.read_csv(file_path)
        present_names = set(df["NAME"].dropna())
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        continue

    row = {}
    for name in all_names:
        row[name] = 'P' if name in present_names else 'A'
    attendance_data[date] = row

# Create DataFrame
summary_df = pd.DataFrame.from_dict(attendance_data, orient='index')
summary_df.index.name = "DATE"
summary_df = summary_df[all_names]
summary_df.index = pd.to_datetime(summary_df.index, dayfirst=True)
summary_df.sort_index(inplace=True)
summary_df.index = summary_df.index.strftime("%d-%m-%Y")

# Save as Excel first (plain format)
summary_df.to_excel(summary_excel)

# Apply styling using openpyxl
from openpyxl import load_workbook

wb = load_workbook(summary_excel)
ws = wb.active
ws.title = "attendance_summary"

# Define styles
green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")  # light green
yellow_fill = PatternFill(start_color="FFF3CD", end_color="FFF3CD", fill_type="solid")  # light yellow

# Style cells
for row in ws.iter_rows(min_row=2, min_col=2):  # Skip headers
    for cell in row:
        if cell.value == "P":
            cell.fill = green_fill
        elif cell.value == "A":
            cell.fill = yellow_fill

# Autofit columns
for col in ws.columns:
    max_length = 0
    col_letter = get_column_letter(col[0].column)
    for cell in col:
        try:
            max_length = max(max_length, len(str(cell.value)))
        except:
            pass
    ws.column_dimensions[col_letter].width = max_length + 2  # add padding

# Save workbook
wb.save(summary_excel)
print(f"✅ Excel saved as '{summary_excel}'")
