import cv2
import pickle
import numpy as np
import os
import csv
import time
from datetime import datetime
from win32com.client import Dispatch
import face_recognition
import sys
from sklearn.neighbors import KNeighborsClassifier

def speak(text):
    speaker = Dispatch("SAPI.SpVoice")
    speaker.Speak(text)

# Load trained data
with open('data/names.pkl', 'rb') as w:
    LABELS = pickle.load(w)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

FACES = np.array(FACES)
LABELS = LABELS[:len(FACES)]

# Train KNN model
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(FACES, LABELS)

video = cv2.VideoCapture(0)
facedetect = cv2.CascadeClassifier('data/haarcascade_frontalface_default.xml')

attendance_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Attendance")
os.makedirs(attendance_folder, exist_ok=True)

ts = time.time()
date = datetime.fromtimestamp(ts).strftime("%d-%m-%Y")
filename = os.path.join(attendance_folder, f"Attendance_{date}.csv")

if not os.path.exists(filename):
    print("❌ No attendance file found for today.")
    speak("No attendance file found for today.")
    sys.exit(1)

print("📷 Please look into the camera for exit scan...")

recognized = False
name = None
timestamp = None

while True:
    ret, frame = video.read()
    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)

    if face_locations and face_encodings:
        (top, right, bottom, left) = face_locations[0]
        face_encoding = face_encodings[0]

        distances, indices = knn.kneighbors([face_encoding], n_neighbors=1)
        if distances[0][0] < 0.6:
            name = knn.predict([face_encoding])[0]
            timestamp = datetime.now().strftime("%H:%M:%S")
            recognized = True

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.rectangle(frame, (left, top - 40), (right, top), (0, 255, 0), -1)
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
            break
        else:
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.putText(frame, "Unknown", (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 1)

    cv2.imshow("Exit Scanner", frame)
    if cv2.waitKey(1) == ord('q'):
        break

video.release()
cv2.destroyAllWindows()

if recognized and name:
    rows = []
    updated = False

    with open(filename, "r", newline='') as file:
        reader = csv.DictReader(file)
        fieldnames = reader.fieldnames if reader.fieldnames else ['NAME', 'ENTRY_TIME']
        if 'EXIT_TIME' not in fieldnames:
            fieldnames.append('EXIT_TIME')
        for row in reader:
            if row['NAME'] == name:
                if not row.get('EXIT_TIME'):
                    row['EXIT_TIME'] = timestamp
                    updated = True
            rows.append(row)

    if updated:
        with open(filename, "w", newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

        print(f"✅ Exit marked for {name} at {timestamp}")
        speak("Exit marked successfully")
    else:
        print(f"⚠️ {name} has not marked attendance yet or already exited.")
        speak("Your entry was not found or already marked exit.")
else:
    speak("Face not recognized. Exit not marked.")
