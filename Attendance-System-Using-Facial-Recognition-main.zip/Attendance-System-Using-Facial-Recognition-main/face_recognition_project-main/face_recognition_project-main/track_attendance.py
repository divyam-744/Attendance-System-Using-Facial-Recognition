import os
import csv
import pickle
from collections import defaultdict
from datetime import datetime

# Load known names from pickle
with open('data/names.pkl', 'rb') as f:
    all_names = pickle.load(f)

def extract_id(name):
    try:
        return int(name.split('_')[-1])
    except:
        return float('inf')

unique_names = sorted(set(all_names), key=extract_id)

print("\n📋 Available Employees:")
for idx, name in enumerate(unique_names):
    print(f"{idx + 1}. {name}")

# Let user choose an employee
try:
    choice = int(input("\n🔎 Enter the number of the employee to view attendance: ")) - 1
    selected_name = unique_names[choice]
except (IndexError, ValueError):
    print("❌ Invalid selection. Exiting.")
    exit()

# Attendance folder
attendance_dir = 'Attendance'
if not os.path.exists(attendance_dir):
    print("❌ No attendance records found.")
    exit()

# Collect all attendance entries for selected person
attendance_summary = defaultdict(lambda: {'ENTRY_TIME': None, 'EXIT_TIME': None})

for file in sorted(os.listdir(attendance_dir)):
    if file.endswith('.csv') and file.startswith('Attendance_'):
        date_str = file.replace('Attendance_', '').replace('.csv', '')
        file_path = os.path.join(attendance_dir, file)

        with open(file_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row.get('NAME', '').strip() == selected_name:
                    entry_time = row.get('ENTRY_TIME', '').strip()
                    exit_time = row.get('EXIT_TIME', '').strip()

                    if date_str not in attendance_summary:
                        attendance_summary[date_str]['ENTRY_TIME'] = entry_time
                        attendance_summary[date_str]['EXIT_TIME'] = exit_time
                    else:
                        # Preserve earliest entry time
                        if entry_time and (
                            not attendance_summary[date_str]['ENTRY_TIME'] or
                            entry_time < attendance_summary[date_str]['ENTRY_TIME']
                        ):
                            attendance_summary[date_str]['ENTRY_TIME'] = entry_time
                        # Always take latest exit time
                        if exit_time and (
                            not attendance_summary[date_str]['EXIT_TIME'] or
                            exit_time > attendance_summary[date_str]['EXIT_TIME']
                        ):
                            attendance_summary[date_str]['EXIT_TIME'] = exit_time

# Display
print(f"\n📅 Attendance for: {selected_name}")
print("-" * 45)
print(f"{'Date':<15}{'Entry Time':<14}{'Exit Time':<14}")
print("-" * 45)

if not attendance_summary:
    print("⚠️ No attendance found for this employee.")
else:
    count = 0
    for date in sorted(attendance_summary.keys(), key=lambda d: datetime.strptime(d, "%d-%m-%Y")):
        record = attendance_summary[date]
        print(f"{date:<15}{record['ENTRY_TIME'] or 'N/A':<14}{record['EXIT_TIME'] or 'N/A':<14}")
        count += 1

    print("-" * 45)
    print(f"✅ Total days present: {count}")
