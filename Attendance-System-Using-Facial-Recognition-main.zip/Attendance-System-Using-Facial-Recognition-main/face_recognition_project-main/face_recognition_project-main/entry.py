from sklearn.neighbors import KNeighborsClassifier
import cv2
import pickle
import numpy as np
import os
import csv
import time
from datetime import datetime
from win32com.client import Dispatch
import face_recognition
import sys

def speak(text):
    speaker = Dispatch("SAPI.SpVoice")
    speaker.Speak(text)

# Setup
video = cv2.VideoCapture(0)
facedetect = cv2.CascadeClassifier('data/haarcascade_frontalface_default.xml')

# Load trained face data
with open('data/names.pkl', 'rb') as w:
    LABELS = pickle.load(w)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

FACES = np.array(FACES)
LABELS = LABELS[:len(FACES)]

# Train KNN classifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(FACES, LABELS)

# Load background image
img_path = r"C:\Users\Divyam Chaturvedi\Desktop\face_recognition_project-main\face_recognition_project-main\background2.png"
imgBackground = cv2.imread(img_path)
if imgBackground is None:
    print(f"Error: Could not load image from {img_path}")
    sys.exit(1)

COL_NAMES = ['NAME', 'ENTRY_TIME', 'EXIT_TIME']
attendance_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Attendance")
os.makedirs(attendance_folder, exist_ok=True)

today = datetime.now().strftime("%d-%m-%Y")

# Frame overlay params
crop_w, crop_h = 580, 360
x_offset = 80
y_offset = 200

while True:
    ret, frame = video.read()
    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)

    recognized = False
    output = None
    attendance = None

    if face_locations and face_encodings:
        (top, right, bottom, left) = face_locations[0]
        face_encoding = face_encodings[0]

        distances, indices = knn.kneighbors([face_encoding], n_neighbors=1)
        if distances[0][0] < 0.6:
            output = knn.predict([face_encoding])[0]
            recognized = True
            timestamp = datetime.now().strftime("%H:%M:%S")
            date = today
            attendance = [str(output), timestamp, ""]

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.rectangle(frame, (left, top - 40), (right, top), (0, 255, 0), -1)
            cv2.putText(frame, str(output), (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
        else:
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.rectangle(frame, (left, top - 40), (right, top), (0, 0, 255), -1)
            cv2.putText(frame, "Unknown", (left, top - 10), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)

    if imgBackground is not None:
        try:
            h, w = frame.shape[:2]
            x_center = w // 2
            y_center = h // 2
            x1 = x_center - crop_w // 2
            y1 = y_center - crop_h // 2
            frame_cropped = frame[y1:y1 + crop_h, x1:x1 + crop_w]
            imgBackground[y_offset:y_offset + crop_h, x_offset:x_offset + crop_w] = frame_cropped
        except Exception as e:
            print("Display error:", e)

        cv2.imshow("Frame", imgBackground)
    else:
        cv2.imshow("Frame", frame)

    key = cv2.waitKey(1)

    if key == ord('o'):
        if recognized and attendance:
            filename = os.path.join(attendance_folder, f"Attendance_{today}.csv")
            can_mark_entry = True

            if os.path.exists(filename):
                with open(filename, "r", newline='') as csvfile:
                    reader = csv.DictReader(csvfile)
                    for row in reader:
                        if row['NAME'] == output:
                            if not row.get('EXIT_TIME'):
                                can_mark_entry = False
                                break

            if not can_mark_entry:
                speak("Previous session not exited. Cannot mark new entry.")
                print(f"❌ Previous entry for '{output}' not closed with EXIT_TIME.")
            else:
                with open(filename, "a", newline='') as csvfile:
                    writer = csv.writer(csvfile)
                    if os.stat(filename).st_size == 0:
                        writer.writerow(COL_NAMES)
                    writer.writerow(attendance)

                speak("Attendance Taken")
                print(f"✅ Attendance marked for {output} at {timestamp}")
            break
        else:
            speak("Face not recognized. Cannot take attendance.")

    if key == ord('q'):
        break

video.release()
cv2.destroyAllWindows()
sys.exit(0)